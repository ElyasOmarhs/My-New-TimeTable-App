
import React, { useReducer, useEffect, createContext, useContext, useState } from 'react';
import { 
  AppState, Teacher, ClassGroup, TimeSettings, DesignSettings, 
  LessonData, COLORS, ToastMessage, PrintDesignSettings, Schedule
} from './types';
import { generateId, calculateTimeSlots, runOptimization, deepMerge } from './utils';

// Components
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Teachers from './components/Teachers';
import Classes from './components/Classes';
import SettingsPage from './components/SettingsPage';
import DesignPage from './components/DesignPage';
import DataMgmt from './components/DataMgmt';
import HelpPage from './components/HelpPage';
import Toast from './components/Toast';
import PrintPreviewPage from './components/PrintPreviewPage';
import TimetableTemplate from './components/TimetableTemplate';

// Icons
import { Menu, Calendar } from 'lucide-react';

// --- Initial State ---

const DEFAULT_STATE: AppState = {
  teachers: [
    { id: 't1', name: 'ښاغلی احمد', color: COLORS[6] },
    { id: 't2', name: 'آغلې ملالۍ', color: COLORS[10] },
  ],
  classes: [
    { id: 'c1', name: '۱۰۱ ټولګی' },
    { id: 'c2', name: '۱۰۲ ټولګی' },
  ],
  schedule: {},
  settings: {
    lessonDuration: 45,
    breakDuration: 15,
    lessonsBeforeBreak: 2,
    startTime: "08:00",
    totalLessons: 6,
  },
  design: {
    lesson: {
      borderColor: '#cbd5e1', backgroundColor: '#ffffff', borderWidth: 1,
      borderRadius: 8, margin: 4, borderStyle: 'solid', shadow: 'none', fontSize: 13
    },
    break: {
      borderColor: '#e2e8f0', backgroundColor: '#f8fafc', borderWidth: 0,
      borderRadius: 8, margin: 4, borderStyle: 'none', shadow: 'inner'
    }
  },
  printDesign: {
    title: 'د ښوونځي اونیز مهال ویش',
    subtitle: 'ښوونیز کال ۱۴۰۳-۱۴۰۴',
    footerText: 'د ښوونځي اداره',
    watermarkText: 'مسوده',
    
    showLegend: true,
    showTeacherName: true,
    showTimes: true,
    showFooter: true,
    showWatermark: false,

    scale: 100,
    paddingX: 40,
    paddingY: 40,
    direction: 'rtl',

    theme: 'classic',
    primaryColor: '#1e293b',
    headerStyle: 'solid',
    fontStyle: 'normal',

    // Typography Defaults
    fontSizeTitle: 32,
    fontSizeSubtitle: 18,
    fontSizeHeader: 14,
    fontSizeSubject: 14,
    fontSizeTeacher: 11,

    // Cell Layout Defaults
    teacherDisplayMode: 'badge',
    cellMinHeight: 90,
    cellVerticalAlign: 'center',
    cellGap: 6,
    cellPadding: 4
  }
};

// --- Actions ---

type Action =
  | { type: 'INIT'; payload: any }
  | { type: 'RECORD' } // Push current state to history
  | { type: 'UNDO' }
  | { type: 'REDO' }
  | { type: 'ADD_TEACHER'; payload: Teacher }
  | { type: 'UPDATE_TEACHER'; payload: Teacher }
  | { type: 'DELETE_TEACHER'; payload: string }
  | { type: 'ADD_CLASS'; payload: ClassGroup }
  | { type: 'UPDATE_CLASS'; payload: ClassGroup }
  | { type: 'DELETE_CLASS'; payload: string }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<TimeSettings> }
  | { type: 'UPDATE_DESIGN'; payload: Partial<DesignSettings> }
  | { type: 'UPDATE_PRINT_DESIGN'; payload: Partial<PrintDesignSettings> }
  | { type: 'SET_LESSON'; payload: { key: string; data: LessonData | null } }
  | { type: 'MOVE_LESSON'; payload: { fromKey: string; toKey: string } }
  | { type: 'OPTIMIZE_SCHEDULE' }
  | { type: 'REPLACE_SCHEDULE'; payload: Schedule };

// --- Reducer with History ---

const HISTORY_LIMIT = 50;

interface HistoryState {
  past: AppState[];
  present: AppState;
  future: AppState[];
}

const reducer = (state: HistoryState, action: Action): HistoryState => {
  const { past, present, future } = state;

  switch (action.type) {
    case 'INIT':
      // Use deepMerge to ensure we don't lose new structural fields when loading old backups
      const safeState = deepMerge(DEFAULT_STATE, action.payload);
      return { past: [], present: safeState, future: [] };
    
    case 'RECORD':
      const newPast = [...past, present];
      if (newPast.length > HISTORY_LIMIT) newPast.shift();
      return { past: newPast, present, future: [] };

    case 'UNDO':
      if (past.length === 0) return state;
      const previous = past[past.length - 1];
      const newPastUndo = past.slice(0, past.length - 1);
      return { past: newPastUndo, present: previous, future: [present, ...future] };

    case 'REDO':
      if (future.length === 0) return state;
      const next = future[0];
      const newFutureRedo = future.slice(1);
      return { past: [...past, present], present: next, future: newFutureRedo };

    // Logic Handlers wrapping state updates
    default:
      const newPresent = appReducer(present, action);
      
      if (newPresent === present) return state; // No change

      const updatedPast = [...past, present];
      if (updatedPast.length > HISTORY_LIMIT) updatedPast.shift();
      
      return {
        past: updatedPast,
        present: newPresent,
        future: []
      };
  }
};

const appReducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'ADD_TEACHER': return { ...state, teachers: [...state.teachers, action.payload] };
    case 'UPDATE_TEACHER': 
      return { ...state, teachers: state.teachers.map(t => t.id === action.payload.id ? action.payload : t) };
    case 'DELETE_TEACHER':
      const newSchedT = { ...state.schedule };
      Object.keys(newSchedT).forEach(k => {
        if (newSchedT[k].teacherId === action.payload) delete newSchedT[k];
      });
      return { ...state, teachers: state.teachers.filter(t => t.id !== action.payload), schedule: newSchedT };

    case 'ADD_CLASS': return { ...state, classes: [...state.classes, action.payload] };
    case 'UPDATE_CLASS': 
      return { ...state, classes: state.classes.map(c => c.id === action.payload.id ? action.payload : c) };
    case 'DELETE_CLASS':
      const newSchedC = { ...state.schedule };
      Object.keys(newSchedC).forEach(k => {
        if (k.startsWith(`${action.payload}_`)) delete newSchedC[k];
      });
      return { ...state, classes: state.classes.filter(c => c.id !== action.payload), schedule: newSchedC };

    case 'UPDATE_SETTINGS': return { ...state, settings: { ...state.settings, ...action.payload } };
    case 'UPDATE_DESIGN': return { ...state, design: { ...state.design, ...action.payload } };
    case 'UPDATE_PRINT_DESIGN': return { ...state, printDesign: { ...state.printDesign, ...action.payload } };

    case 'SET_LESSON':
      const newSchedule = { ...state.schedule };
      if (action.payload.data === null) {
        delete newSchedule[action.payload.key];
      } else {
        newSchedule[action.payload.key] = action.payload.data;
      }
      return { ...state, schedule: newSchedule };

    case 'MOVE_LESSON':
      const { fromKey, toKey } = action.payload;
      const schedCopy = { ...state.schedule };
      const itemToMove = schedCopy[fromKey];
      const itemAtTarget = schedCopy[toKey];

      if (!itemToMove) return state;

      schedCopy[toKey] = itemToMove;
      if (itemAtTarget) {
        schedCopy[fromKey] = itemAtTarget;
      } else {
        delete schedCopy[fromKey];
      }
      return { ...state, schedule: schedCopy };
      
    case 'OPTIMIZE_SCHEDULE':
        const slots = calculateTimeSlots(state.settings);
        const optimizedSchedule = runOptimization(state.schedule, state.classes, slots);
        return { ...state, schedule: optimizedSchedule };
    
    case 'REPLACE_SCHEDULE':
        return { ...state, schedule: action.payload };

    default: return state;
  }
};

// --- Context ---

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  canUndo: boolean;
  canRedo: boolean;
  toasts: ToastMessage[];
  addToast: (type: ToastMessage['type'], msg: string) => void;
  removeToast: (id: string) => void;
}

export const AppContext = createContext<AppContextType>({} as any);

// --- Main App Component ---

const STORAGE_KEY = 'school_scheduler_master_v1';

export default function App() {
  const initData = (): HistoryState => {
    try {
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        const parsed = JSON.parse(local);
        // Validate and merge with default state to prevent crashes from old backups
        const mergedState = deepMerge(DEFAULT_STATE, parsed);
        return { past: [], present: mergedState, future: [] };
      }
    } catch (e) { console.error(e); }
    return { past: [], present: DEFAULT_STATE, future: [] };
  };

  const [store, dispatch] = useReducer(reducer, {}, initData);
  const [activePage, setActivePage] = useState('dashboard');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Persist
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store.present));
  }, [store.present]);

  const addToast = (type: ToastMessage['type'], message: string) => {
    const id = generateId();
    setToasts(prev => [...prev, { id, type, message }]);
  };
  const removeToast = (id: string) => setToasts(prev => prev.filter(t => t.id !== id));

  const renderPage = () => {
    if (activePage === 'print-preview') {
        return <PrintPreviewPage onBack={() => setActivePage('data')} />;
    }

    switch(activePage) {
      case 'dashboard': return <Dashboard />;
      case 'teachers': return <Teachers />;
      case 'classes': return <Classes />;
      case 'settings': return <SettingsPage />;
      case 'design': return <DesignPage />;
      case 'data': return <DataMgmt setPage={setActivePage} />;
      case 'help': return <HelpPage />;
      default: return <Dashboard />;
    }
  };

  const contextValue = {
    state: store.present,
    dispatch,
    canUndo: store.past.length > 0,
    canRedo: store.future.length > 0,
    toasts,
    addToast,
    removeToast
  };

  const isPreviewMode = activePage === 'print-preview';

  return (
    <AppContext.Provider value={contextValue}>
      <div className="flex h-screen overflow-hidden bg-slate-50 text-slate-900 font-sans">
        
        {!isPreviewMode && (
            <div 
                className={`
                    sidebar z-40 bg-slate-900 text-white shadow-2xl transition-all duration-300 ease-in-out flex-shrink-0
                    fixed inset-y-0 right-0 
                    lg:static lg:h-full
                    ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
                `}
                style={{ width: isSidebarCollapsed ? '5rem' : '16rem' }} 
            >
              <Sidebar 
                 activePage={activePage} 
                 setPage={(p) => { setActivePage(p); setIsMobileMenuOpen(false); }} 
                 isCollapsed={isSidebarCollapsed}
                 toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              />
            </div>
        )}
        
        <div className="app-container flex-1 flex flex-col h-full overflow-hidden relative min-w-0 transition-all duration-300">
           {!isPreviewMode && (
               <header className="lg:hidden bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-sm z-30 shrink-0">
                    <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors">
                        <Menu size={24} />
                    </button>
                    <div className="font-bold text-slate-700 flex items-center gap-2">
                        <span className="text-lg">مهال ویش</span>
                        <div className="bg-primary-600 p-1.5 rounded-lg shadow-sm">
                            <Calendar className="text-white" size={18} />
                        </div>
                    </div>
               </header>
           )}

           {isMobileMenuOpen && !isPreviewMode && (
            <div className="fixed inset-0 bg-black/50 z-30 lg:hidden backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
           )}
           
           <main className={`flex-1 overflow-auto bg-slate-50 ${isPreviewMode ? 'p-0' : 'p-4 lg:p-6'}`}>
              {renderPage()}
           </main>
        </div>

        <div className="toast-container">
            <Toast toasts={toasts} removeToast={removeToast} />
        </div>

        <div id="export-canvas-container" style={{ width: '2000px', boxSizing: 'border-box' }}>
            <TimetableTemplate state={store.present} />
        </div>

      </div>
    </AppContext.Provider>
  );
}
