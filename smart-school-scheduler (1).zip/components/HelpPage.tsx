
import React from 'react';
import { BookOpen, MousePointer, ShieldCheck, Zap, Printer } from 'lucide-react';

const HelpPage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto pb-12">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">د پروګرام کارولو لارښود</h2>
      
      <div className="space-y-6">
        
        {/* Intro */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex items-center gap-3 mb-4 text-primary-600">
                <BookOpen size={24} />
                <h3 className="text-lg font-bold">لومړني ګامونه</h3>
            </div>
            <p className="text-slate-600 leading-relaxed mb-4">
                د ښوونځي د مهال ویش هوښیار سیستم ته ښه راغلاست. په دې سیستم کې تاسو کولی شئ لومړی خپل <strong>ښوونکي</strong> او <strong>ټولګي</strong> تعریف کړئ او بیا په ډشبورډ کې مهال ویش تنظیم کړئ.
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600">
                <li>ستاسو معلومات په اوتومات ډول په براوزر کې خوندي کیږي.</li>
                <li>د پیل لپاره، د ښي اړخ مینو څخه د ښوونکو مدیریت برخې ته لاړ شئ.</li>
            </ul>
        </div>

        {/* Interactive */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex items-center gap-3 mb-4 text-indigo-600">
                <MousePointer size={24} />
                <h3 className="text-lg font-bold">د مهال ویش تنظیم کول</h3>
            </div>
            <div className="space-y-4 text-slate-600">
                <p>
                    <strong>لوست سمول:</strong> په جدول کې په هره خالي یا ډکه خونه کلیک وکړئ ترڅو د درس او ښوونکي ټاکلو کړکۍ پرانیستل شي.
                </p>
                <p>
                    <strong>جابجایي (Drag & Drop):</strong> تاسو کولی شئ لوستونه د موږک په واسطه ونیسئ او د <em>همغه ټولګي</em> په بله خونه کې یې خوشې کړئ ترڅو ځای یې بدل شي.
                </p>
                <p>
                    <strong>تفریح/دمه:</strong> په ترتیباتو برخه کې کولی شئ د تفریح تعداد او وخت وټاکئ. دا وقفې په اوتومات ډول په جدول کې ښودل کیږي.
                </p>
            </div>
        </div>

        {/* Conflicts & Optimization */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex items-center gap-3 mb-4 text-amber-600">
                <Zap size={24} />
                <h3 className="text-lg font-bold">تضاد موندنه او مصنوعي ځیرکتیا</h3>
            </div>
            <p className="text-slate-600 mb-3">
                که یو ښوونکی په یو وخت کې د دوو ټولګیو لپاره وټاکل شي، سیستم به تاسو ته د خبرتیا نښې <span className="inline-block align-middle"><ShieldCheck size={16} className="text-red-500"/></span> او سرې نښې سره خبر درکړي.
            </p>
            <div className="bg-amber-50 p-4 rounded-lg border border-amber-100 text-sm text-amber-800">
                <strong>مهم ټکی:</strong> په ډشبورډ کې د "هوښیار سمون" تڼۍ هڅه کوي چې د درسونو په تصادفي جابجایۍ سره موجود تضادونه حل کړي. د دې کارولو دمخه، اوسنی مهال ویش په حافظه (History) کې خوندي کیږي ترڅو وکولی شئ د اړتیا په صورت کې "شاته" (Undo) وکړئ.
            </div>
        </div>

        {/* Print */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex items-center gap-3 mb-4 text-purple-600">
                <Printer size={24} />
                <h3 className="text-lg font-bold">چاپ او خروجي</h3>
            </div>
            <p className="text-slate-600">
                د وروستۍ نسخې ترلاسه کولو لپاره، "معلومات او خروجي" مینو ته لاړ شئ او د <strong>چاپ / PDF</strong> تڼۍ کلیک وکړئ.
                <br/>
                د براوزر د چاپ په کړکۍ کې، پاڼه په <strong>Landscape (افقی)</strong> حالت کې وټاکئ او د رنګونو د سم چاپ لپاره <strong>Background Graphics</strong> اختیار فعال کړئ.
            </p>
        </div>

      </div>
    </div>
  );
};

export default HelpPage;
