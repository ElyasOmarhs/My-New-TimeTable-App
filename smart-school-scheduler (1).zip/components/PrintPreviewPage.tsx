
import React, { useContext, useState } from 'react';
import { AppContext } from '../App';
import { ArrowRight, Download, Layout, Type, Palette, Printer, Stamp, Eye, Grid, AlignVerticalSpaceAround, MoveVertical, ChevronLeft, ChevronRight, Settings2, Maximize2, Minimize2, X } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import TimetableTemplate from './TimetableTemplate';

interface Props {
  onBack: () => void;
}

type TabType = 'layout' | 'content' | 'style' | 'extras';

const PrintPreviewPage: React.FC<Props> = ({ onBack }) => {
  const { state, dispatch, addToast } = useContext(AppContext);
  const { printDesign } = state;
  const [activeTab, setActiveTab] = useState<TabType>('layout');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const updateDesign = (key: keyof typeof printDesign, value: any) => {
    dispatch({ type: 'UPDATE_PRINT_DESIGN', payload: { [key]: value } });
  };

  const handleDownload = async () => {
    const element = document.getElementById('export-canvas-container');
    if (!element) return;

    addToast('info', 'د لوړ کیفیت فایل جوړولو په حال کې...');

    try {
        // Wait a moment for fonts to potentially settle if changed
        await new Promise(r => setTimeout(r, 500));

        const canvas = await html2canvas(element, {
            scale: 3, // Higher scale for crisp text
            useCORS: true,
            logging: false,
            backgroundColor: '#ffffff',
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.95);
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'mm',
            format: 'a4'
        });

        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgProps = pdf.getImageProperties(imgData);
        const ratio = imgProps.width / imgProps.height;
        
        let renderWidth = pdfWidth;
        let renderHeight = pdfWidth / ratio;

        // Fit within the page logic
        if (renderHeight > pdfHeight) {
             renderHeight = pdfHeight;
             renderWidth = pdfHeight * ratio;
        }

        // Center the image
        const x = (pdfWidth - renderWidth) / 2;
        const y = (pdfHeight - renderHeight) / 2;

        pdf.addImage(imgData, 'JPEG', x, y, renderWidth, renderHeight);
        
        const date = new Date();
        const dateStr = date.getFullYear() + 
                        String(date.getMonth() + 1).padStart(2, '0') + 
                        String(date.getDate()).padStart(2, '0');

        pdf.save(`timetable_pro_${dateStr}.pdf`);
        addToast('success', 'PDF فایل ډاونلوډ شو');

    } catch (e) {
        console.error(e);
        addToast('error', 'د فایل په جوړولو کې ستونزه');
    }
  };

  const TabButton = ({ id, label, icon }: { id: TabType, label: string, icon: React.ReactNode }) => (
    <button 
        onClick={() => setActiveTab(id)}
        className={`flex-1 py-3 flex flex-col items-center justify-center gap-1 text-xs font-medium transition-all border-b-2 ${
            activeTab === id 
            ? 'border-indigo-600 text-indigo-700 bg-indigo-50' 
            : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'
        }`}
    >
        {icon}
        <span>{label}</span>
    </button>
  );

  return (
    <div className="h-full flex flex-col bg-slate-100">
      {/* Top Bar - Hidden in Full Screen */}
      {!isFullScreen && (
          <div className="bg-white border-b border-slate-200 px-4 md:px-6 py-3 flex justify-between items-center shadow-sm z-20 flex-shrink-0">
            <div className="flex items-center gap-4">
                <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-600" title="بېرته مدیریت ته">
                    <ArrowRight size={24} />
                </button>
                <div className="flex items-center gap-3">
                    <h2 className="text-lg font-bold text-slate-800 hidden md:block">د چاپ او PDF سټوډیو</h2>
                    <span className="bg-indigo-100 text-indigo-700 text-[10px] px-2 py-0.5 rounded-full font-bold">PRO</span>
                    
                    {!isSidebarOpen && (
                        <button 
                            onClick={() => setIsSidebarOpen(true)}
                            className="flex items-center gap-2 text-sm text-indigo-600 hover:bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-100 transition-colors"
                        >
                            <Settings2 size={16} />
                            <span>ترتیبات</span>
                        </button>
                    )}
                </div>
            </div>
            <div className="flex gap-3">
                <button 
                    onClick={() => setIsFullScreen(true)}
                    className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"
                    title="پوره سکرین"
                >
                    <Maximize2 size={20} />
                </button>
                <button 
                    onClick={() => window.print()}
                    className="px-3 md:px-4 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg flex items-center gap-2 font-medium transition-colors text-sm"
                >
                    <Printer size={18} />
                    <span className="hidden md:inline">سمدستي چاپ</span>
                </button>
                <button 
                    onClick={handleDownload}
                    className="px-4 md:px-5 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg flex items-center gap-2 shadow-lg shadow-indigo-200 font-bold transition-colors text-sm"
                >
                    <Download size={18} />
                    <span className="hidden md:inline">د وروستۍ نسخې ډاونلوډ</span>
                    <span className="md:hidden">ډاونلوډ</span>
                </button>
            </div>
          </div>
      )}

      <div className="flex-1 overflow-hidden flex relative">
        
        {/* Left Control Panel (Collapsible) - Hidden in Full Screen */}
        {!isFullScreen && (
            <div 
                className={`bg-white border-l border-slate-200 flex flex-col shadow-xl z-10 transition-all duration-300 ease-in-out absolute inset-y-0 right-0 md:static ${
                    isSidebarOpen ? 'w-80 translate-x-0' : 'w-0 translate-x-full opacity-0 md:opacity-100 md:w-0 md:translate-x-0 overflow-hidden'
                }`}
            >
                {/* Collapse Button */}
                <button 
                    onClick={() => setIsSidebarOpen(false)}
                    className="absolute top-1/2 -left-3 z-50 bg-white border border-slate-200 shadow-md rounded-full p-1 text-slate-500 hover:text-indigo-600 hidden md:block"
                    title="د ترتیباتو پینل وتړئ"
                >
                    <ChevronRight size={16} />
                </button>

                {/* Tabs */}
                <div className="flex border-b border-slate-200">
                    <TabButton id="layout" label="جوړښت" icon={<Layout size={18} />} />
                    <TabButton id="content" label="محتوا" icon={<Type size={18} />} />
                    <TabButton id="style" label="سټایل" icon={<Palette size={18} />} />
                    <TabButton id="extras" label="نور" icon={<Stamp size={18} />} />
                </div>

                {/* Controls Scroll Area */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6 pb-20">
                    
                    {/* LAYOUT TAB */}
                    {activeTab === 'layout' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">د حجرو ابعاد (مهم)</label>
                                <div className="space-y-4 bg-amber-50 border border-amber-100 p-3 rounded-lg">
                                    <div>
                                        <div className="flex justify-between text-sm mb-1 text-slate-700">
                                            <span>د قطار لږترلږه لوړوالی</span>
                                            <span className="font-mono text-slate-500">{printDesign.cellMinHeight || 90}px</span>
                                        </div>
                                        <input 
                                            type="range" min="30" max="300" step="5"
                                            value={printDesign.cellMinHeight || 90}
                                            onChange={(e) => updateDesign('cellMinHeight', parseInt(e.target.value))}
                                            className="w-full accent-amber-600"
                                        />
                                        <p className="text-[10px] text-amber-700 mt-1 leading-tight">که متنونه نه ځاییږي، دا اندازه لوړه کړئ.</p>
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-sm mb-1 text-slate-700">
                                            <span>داخلي واټن (Padding)</span>
                                            <span className="font-mono text-slate-500">{printDesign.cellPadding || 4}px</span>
                                        </div>
                                        <input 
                                            type="range" min="0" max="50" step="1"
                                            value={printDesign.cellPadding || 4}
                                            onChange={(e) => updateDesign('cellPadding', parseInt(e.target.value))}
                                            className="w-full accent-amber-600"
                                        />
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-sm mb-1 text-slate-700">
                                            <span>د لوست او ښوونکي ترمنځ واټن</span>
                                            <span className="font-mono text-slate-500">{printDesign.cellGap || 6}px</span>
                                        </div>
                                        <input 
                                            type="range" min="0" max="50" step="1"
                                            value={printDesign.cellGap || 6}
                                            onChange={(e) => updateDesign('cellGap', parseInt(e.target.value))}
                                            className="w-full accent-amber-600"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm mb-1 text-slate-700">د محتوا عمودي سمون</label>
                                        <div className="flex bg-white rounded-lg border border-amber-200 p-1">
                                            <button 
                                                onClick={() => updateDesign('cellVerticalAlign', 'start')}
                                                className={`flex-1 py-1 text-xs rounded ${printDesign.cellVerticalAlign === 'start' ? 'bg-amber-100 text-amber-800 font-bold' : 'text-slate-500'}`}
                                            >
                                                پورته
                                            </button>
                                            <button 
                                                onClick={() => updateDesign('cellVerticalAlign', 'center')}
                                                className={`flex-1 py-1 text-xs rounded ${printDesign.cellVerticalAlign === 'center' ? 'bg-amber-100 text-amber-800 font-bold' : 'text-slate-500'}`}
                                            >
                                                منځ
                                            </button>
                                            <button 
                                                onClick={() => updateDesign('cellVerticalAlign', 'end')}
                                                className={`flex-1 py-1 text-xs rounded ${printDesign.cellVerticalAlign === 'end' ? 'bg-amber-100 text-amber-800 font-bold' : 'text-slate-500'}`}
                                            >
                                                ښکته
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">د پاڼې عمومي کچه</label>
                                <div className="space-y-4">
                                    <div>
                                        <div className="flex justify-between text-sm mb-1">
                                            <span>غټوالی (Zoom)</span>
                                            <span className="font-mono text-slate-500">{printDesign.scale}%</span>
                                        </div>
                                        <input 
                                            type="range" min="20" max="200" step="5"
                                            value={printDesign.scale}
                                            onChange={(e) => updateDesign('scale', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-sm mb-1">
                                            <span>د پاڼې عمودي څنډه</span>
                                            <span className="font-mono text-slate-500">{printDesign.paddingY}px</span>
                                        </div>
                                        <input 
                                            type="range" min="0" max="200" step="10"
                                            value={printDesign.paddingY}
                                            onChange={(e) => updateDesign('paddingY', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-sm mb-1">
                                            <span>د پاڼې افقي څنډه</span>
                                            <span className="font-mono text-slate-500">{printDesign.paddingX}px</span>
                                        </div>
                                        <input 
                                            type="range" min="0" max="200" step="10"
                                            value={printDesign.paddingX}
                                            onChange={(e) => updateDesign('paddingX', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">د پاڼې لوری</label>
                                <div className="grid grid-cols-2 gap-2">
                                    <button 
                                        onClick={() => updateDesign('direction', 'rtl')}
                                        className={`px-3 py-2 rounded border text-sm ${printDesign.direction === 'rtl' ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-bold' : 'bg-white border-slate-200'}`}
                                    >
                                        راست‌چین (RTL)
                                    </button>
                                    <button 
                                        onClick={() => updateDesign('direction', 'ltr')}
                                        className={`px-3 py-2 rounded border text-sm ${printDesign.direction === 'ltr' ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-bold' : 'bg-white border-slate-200'}`}
                                    >
                                        چپ‌چین (LTR)
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* CONTENT TAB */}
                    {activeTab === 'content' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">سرلیکونه</label>
                                <div className="space-y-3">
                                    <input 
                                        type="text" placeholder="اصلي سرلیک"
                                        value={printDesign.title}
                                        onChange={(e) => updateDesign('title', e.target.value)}
                                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
                                    />
                                    <input 
                                        type="text" placeholder="فرعي سرلیک"
                                        value={printDesign.subtitle}
                                        onChange={(e) => updateDesign('subtitle', e.target.value)}
                                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">اضافي معلومات</label>
                                <div className="space-y-2">
                                    {[
                                        { key: 'showTimes', label: 'د درسونو وخت (پیل-پای)' },
                                        { key: 'showLegend', label: 'د ښوونکو رنګ لارښود' },
                                        { key: 'showFooter', label: 'پاورقی (Footer)' },
                                    ].map((item) => (
                                        <label key={item.key} className="flex items-center gap-3 p-2 hover:bg-slate-50 rounded cursor-pointer transition-colors">
                                            <input 
                                                type="checkbox" 
                                                checked={printDesign[item.key as keyof typeof printDesign] as boolean}
                                                onChange={(e) => updateDesign(item.key as keyof typeof printDesign, e.target.checked)}
                                                className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                                            />
                                            <span className="text-sm text-slate-700">{item.label}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* STYLE TAB */}
                    {activeTab === 'style' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                            
                            {/* Teacher Display Controls */}
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">د ښوونکي نوم ښودل</label>
                                <div className="grid grid-cols-2 gap-2">
                                    {[
                                        { id: 'badge', label: 'رنګه نښه (Badge)' },
                                        { id: 'text', label: 'یوازې رنګه متن' },
                                        { id: 'dot', label: 'رنګه ټکی (بې نومه)' },
                                        { id: 'hidden', label: 'پټ' }
                                    ].map((mode) => (
                                        <button
                                            key={mode.id}
                                            onClick={() => updateDesign('teacherDisplayMode', mode.id)}
                                            className={`px-2 py-2 rounded border text-xs transition-all ${
                                                (printDesign.teacherDisplayMode || 'badge') === mode.id
                                                ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-bold shadow-sm' 
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            {mode.label}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Typography Controls */}
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">د متن اندازه (ټایپوګرافي)</label>
                                <div className="space-y-4 bg-slate-50 p-3 rounded-lg border border-slate-200">
                                    <div>
                                        <div className="flex justify-between text-xs mb-1 text-slate-600">
                                            <span>اصلي سرلیک</span>
                                            <span className="font-mono">{printDesign.fontSizeTitle || 32}px</span>
                                        </div>
                                        <input 
                                            type="range" min="10" max="100" step="1"
                                            value={printDesign.fontSizeTitle || 32}
                                            onChange={(e) => updateDesign('fontSizeTitle', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-xs mb-1 text-slate-600">
                                            <span>د جدول سرلیکونه</span>
                                            <span className="font-mono">{printDesign.fontSizeHeader || 14}px</span>
                                        </div>
                                        <input 
                                            type="range" min="8" max="40" step="1"
                                            value={printDesign.fontSizeHeader || 14}
                                            onChange={(e) => updateDesign('fontSizeHeader', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-xs mb-1 text-slate-600">
                                            <span>د لوست نوم (Subject)</span>
                                            <span className="font-mono">{printDesign.fontSizeSubject || 14}px</span>
                                        </div>
                                        <input 
                                            type="range" min="8" max="60" step="1"
                                            value={printDesign.fontSizeSubject || 14}
                                            onChange={(e) => updateDesign('fontSizeSubject', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-xs mb-1 text-slate-600">
                                            <span>د ښوونکي نوم (Teacher)</span>
                                            <span className="font-mono">{printDesign.fontSizeTeacher || 10}px</span>
                                        </div>
                                        <input 
                                            type="range" min="6" max="40" step="1"
                                            value={printDesign.fontSizeTeacher || 10}
                                            onChange={(e) => updateDesign('fontSizeTeacher', parseInt(e.target.value))}
                                            className="w-full accent-indigo-600"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="border-t pt-4">
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">رنګین ټیم (Theme)</label>
                                <div className="grid grid-cols-2 gap-2 mb-4">
                                    {['classic', 'modern', 'minimal', 'colorful', 'corporate'].map((t) => (
                                        <button
                                            key={t}
                                            onClick={() => updateDesign('theme', t)}
                                            className={`px-3 py-2 rounded border text-sm capitalize transition-all ${
                                                printDesign.theme === t 
                                                ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-bold shadow-sm' 
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            {t}
                                        </button>
                                    ))}
                                </div>
                                
                                <div className="flex gap-3 items-center bg-slate-50 p-3 rounded-lg">
                                    <input 
                                        type="color" 
                                        value={printDesign.primaryColor}
                                        onChange={(e) => updateDesign('primaryColor', e.target.value)}
                                        className="w-8 h-8 rounded cursor-pointer border shadow-sm"
                                    />
                                    <div className="flex-1">
                                        <div className="text-xs font-bold text-slate-700">د سرلیک رنګ</div>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">د سرلیک سټایل</label>
                                <select 
                                    value={printDesign.headerStyle} 
                                    onChange={(e) => updateDesign('headerStyle', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-lg bg-white text-sm"
                                >
                                    <option value="solid">ډک (Solid)</option>
                                    <option value="outline">خط دار (Outline)</option>
                                    <option value="simple">ساده (Simple)</option>
                                </select>
                            </div>
                        </div>
                    )}

                    {/* EXTRAS TAB */}
                    {activeTab === 'extras' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">واټر مارک (Watermark)</label>
                                <div className="space-y-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
                                    <label className="flex items-center gap-2 cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            checked={printDesign.showWatermark}
                                            onChange={(e) => updateDesign('showWatermark', e.target.checked)}
                                            className="rounded text-indigo-600"
                                        />
                                        <span className="text-sm font-bold text-slate-700">واټر مارک فعالول</span>
                                    </label>
                                    {printDesign.showWatermark && (
                                        <input 
                                            type="text" 
                                            value={printDesign.watermarkText}
                                            onChange={(e) => updateDesign('watermarkText', e.target.value)}
                                            className="w-full px-3 py-2 border rounded-lg text-sm"
                                            placeholder="د واټر مارک متن (مثلاً: مسوده)"
                                        />
                                    )}
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">دودیزه پاورقی</label>
                                <textarea 
                                    value={printDesign.footerText}
                                    onChange={(e) => updateDesign('footerText', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-lg text-sm h-24"
                                    placeholder="هغه متن چې د ټولو پاڼو په پای کې ښودل کیږي..."
                                />
                            </div>
                        </div>
                    )}

                </div>
            </div>
        )}

        {/* Right Preview Area */}
        <div className={`
            flex-1 bg-slate-900 overflow-auto flex items-center justify-center relative transition-all duration-300
            ${isFullScreen ? 'fixed inset-0 z-50' : 'bg-slate-200/80'}
        `}>
            
            {isFullScreen && (
                <button 
                    onClick={() => setIsFullScreen(false)}
                    className="absolute top-4 right-4 z-50 p-3 bg-white/10 text-white hover:bg-white/20 backdrop-blur rounded-full transition-all"
                >
                    <X size={24} />
                </button>
            )}

            {/* Scale / Info Indicators */}
            <div className="absolute top-4 left-4 flex gap-2 z-10 pointer-events-none">
                <div className="bg-slate-800 text-white px-3 py-1 rounded-md text-xs shadow-sm opacity-70 backdrop-blur-sm">
                   {printDesign.scale}% Scale
                </div>
                <div className="bg-slate-800 text-white px-3 py-1 rounded-md text-xs shadow-sm opacity-70 backdrop-blur-sm">
                   A4 Landscape
                </div>
            </div>
            
            {/* The paper visual - Fixed Dimensions for A4 Landscape */}
            <div 
                className="bg-white shadow-2xl transition-all duration-300 origin-top flex flex-col overflow-hidden" 
                style={{ 
                    width: '297mm', 
                    height: '210mm', // Fixed height to simulate actual paper cut-off
                    transform: 'scale(0.65)' 
                }}
            >
                <TimetableTemplate state={state} previewMode={true} />
            </div>
        </div>
      </div>
    </div>
  );
};

export default PrintPreviewPage;
