
import React, { useContext, useState } from 'react';
import { AppContext } from '../App';
import { Plus, Trash2, Edit2, Check, X, Palette, Shuffle } from 'lucide-react';
import { generateId } from '../utils';
import { COLORS } from '../types';
import ConfirmModal from './ConfirmModal';

const Teachers: React.FC = () => {
  const { state, dispatch, addToast } = useContext(AppContext);
  const [newTeacherName, setNewTeacherName] = useState('');
  const [colorMode, setColorMode] = useState<'random' | 'custom'>('random');
  const [customColor, setCustomColor] = useState('#3b82f6');

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeacherName.trim()) return;

    const color = colorMode === 'random' 
        ? COLORS[Math.floor(Math.random() * COLORS.length)] 
        : customColor;

    dispatch({ 
        type: 'ADD_TEACHER', 
        payload: { id: generateId(), name: newTeacherName, color } 
    });
    setNewTeacherName('');
    // Keep custom color preference but reset name
    addToast('success', 'نوی ښوونکی اضافه شو');
  };

  const startEdit = (t: any) => {
    setEditingId(t.id);
    setEditName(t.name);
  };

  const saveEdit = (t: any) => {
    dispatch({ type: 'UPDATE_TEACHER', payload: { ...t, name: editName } });
    setEditingId(null);
    addToast('success', 'د ښوونکي نوم سم شو');
  };

  const confirmDelete = () => {
    if (deleteId) {
        dispatch({ type: 'DELETE_TEACHER', payload: deleteId });
        addToast('success', 'ښوونکی حذف شو');
        setDeleteId(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">د ښوونکو مدیریت</h2>
      
      <form onSubmit={handleAdd} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mb-8">
        <div className="flex flex-col gap-4">
            <div className="flex gap-4">
                <input 
                type="text" 
                value={newTeacherName}
                onChange={(e) => setNewTeacherName(e.target.value)}
                placeholder="د نوي ښوونکي نوم..."
                className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none"
                />
                <button 
                    type="submit"
                    disabled={!newTeacherName.trim()}
                    className="bg-primary-600 hover:bg-primary-700 text-white px-6 rounded-xl flex items-center gap-2 disabled:opacity-50 transition-colors whitespace-nowrap"
                >
                    <Plus size={20} />
                    <span>زیاتول</span>
                </button>
            </div>
            
            {/* Color Selection */}
            <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-xl">
                <span className="text-sm font-bold text-slate-600">رنګ ټاکل:</span>
                
                <div className="flex gap-2">
                    <button
                        type="button"
                        onClick={() => setColorMode('random')}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm transition-colors border ${
                            colorMode === 'random' 
                            ? 'bg-white border-primary-500 text-primary-600 shadow-sm ring-1 ring-primary-500' 
                            : 'bg-transparent border-transparent text-slate-500 hover:bg-slate-200'
                        }`}
                    >
                        <Shuffle size={14} />
                        <span>تصادفي</span>
                    </button>
                    <button
                        type="button"
                        onClick={() => setColorMode('custom')}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm transition-colors border ${
                            colorMode === 'custom' 
                            ? 'bg-white border-primary-500 text-primary-600 shadow-sm ring-1 ring-primary-500' 
                            : 'bg-transparent border-transparent text-slate-500 hover:bg-slate-200'
                        }`}
                    >
                        <Palette size={14} />
                        <span>دودیز</span>
                    </button>
                </div>

                {colorMode === 'custom' && (
                    <div className="flex items-center gap-2 animate-in fade-in duration-300">
                        <input 
                            type="color" 
                            value={customColor} 
                            onChange={(e) => setCustomColor(e.target.value)}
                            className="w-8 h-8 rounded cursor-pointer border-2 border-white shadow-sm" 
                        />
                        <span className="text-xs text-slate-400" dir="ltr">{customColor}</span>
                    </div>
                )}
            </div>
        </div>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {state.teachers.map(t => (
            <div key={t.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex items-center justify-between group">
                {editingId === t.id ? (
                    <div className="flex items-center gap-2 w-full">
                        <input 
                            type="text" 
                            value={editName} 
                            onChange={(e) => setEditName(e.target.value)}
                            className="flex-1 px-2 py-1 border rounded bg-slate-50"
                            autoFocus
                        />
                        <button onClick={() => saveEdit(t)} className="text-green-600 p-1 bg-green-50 rounded hover:bg-green-100"><Check size={16} /></button>
                        <button onClick={() => setEditingId(null)} className="text-slate-400 p-1 hover:bg-slate-100 rounded"><X size={16} /></button>
                    </div>
                ) : (
                    <>
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-sm border-2 border-white" style={{ backgroundColor: t.color }}>
                                {t.name.charAt(0)}
                            </div>
                            <span className="font-medium text-slate-700">{t.name}</span>
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => startEdit(t)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                                <Edit2 size={18} />
                            </button>
                            <button onClick={() => setDeleteId(t.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                                <Trash2 size={18} />
                            </button>
                        </div>
                    </>
                )}
            </div>
        ))}
      </div>

      <ConfirmModal 
        isOpen={!!deleteId}
        message="د دې ښوونکي په لرې کولو سره به د هغه ټول اړوند لوستونه له مهال ویش څخه لرې شي. ایا دوام ورکوئ؟"
        onCancel={() => setDeleteId(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
};

export default Teachers;
