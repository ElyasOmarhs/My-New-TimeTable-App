
import React, { useContext, useState } from 'react';
import { AppContext } from '../App';
import { Save } from 'lucide-react';
import { CellDesign } from '../types';

const DesignPage: React.FC = () => {
  const { state, dispatch, addToast } = useContext(AppContext);
  // Deep copy to avoid reference issues during edit
  const [design, setDesign] = useState(JSON.parse(JSON.stringify(state.design)));

  const updateField = (type: 'lesson' | 'break', field: keyof CellDesign, value: any) => {
    setDesign((prev: any) => ({
        ...prev,
        [type]: { ...prev[type], [field]: value }
    }));
  };

  const handleSave = () => {
    dispatch({ type: 'UPDATE_DESIGN', payload: design });
    addToast('success', 'د مهال ویش ظاهري بڼه بدله شوه');
  };

  const renderControls = (type: 'lesson' | 'break', label: string) => (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">{label}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">د شالید (Background) رنګ</label>
                <div className="flex gap-2">
                    <input type="color" className="w-10 h-10 rounded cursor-pointer" value={design[type].backgroundColor} onChange={(e) => updateField(type, 'backgroundColor', e.target.value)} />
                    <input type="text" className="flex-1 border rounded px-2 text-sm" value={design[type].backgroundColor} onChange={(e) => updateField(type, 'backgroundColor', e.target.value)} />
                </div>
            </div>

            <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">د څنډې (Border) رنګ</label>
                <div className="flex gap-2">
                    <input type="color" className="w-10 h-10 rounded cursor-pointer" value={design[type].borderColor} onChange={(e) => updateField(type, 'borderColor', e.target.value)} />
                    <input type="text" className="flex-1 border rounded px-2 text-sm" value={design[type].borderColor} onChange={(e) => updateField(type, 'borderColor', e.target.value)} />
                </div>
            </div>

            <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">د څنډې پنډوالی ({design[type].borderWidth}px)</label>
                <input type="range" min="0" max="5" className="w-full" value={design[type].borderWidth} onChange={(e) => updateField(type, 'borderWidth', parseInt(e.target.value))} />
            </div>

            <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">د کونجونو ګردوالی ({design[type].borderRadius}px)</label>
                <input type="range" min="0" max="20" className="w-full" value={design[type].borderRadius} onChange={(e) => updateField(type, 'borderRadius', parseInt(e.target.value))} />
            </div>
            
            <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">داخلي واټن/Margin ({design[type].margin}px)</label>
                <input type="range" min="0" max="10" className="w-full" value={design[type].margin} onChange={(e) => updateField(type, 'margin', parseInt(e.target.value))} />
            </div>

            {type === 'lesson' && (
                 <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">د فونټ اندازه ({design[type].fontSize}px)</label>
                    <input type="range" min="10" max="20" className="w-full" value={design[type].fontSize} onChange={(e) => updateField(type, 'fontSize', parseInt(e.target.value))} />
                </div>
            )}

        </div>
        
        {/* Preview */}
        <div className="mt-6 p-4 bg-slate-100 rounded-lg flex justify-center">
            <div style={{
                width: '140px', height: '80px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                backgroundColor: design[type].backgroundColor,
                borderColor: design[type].borderColor,
                borderWidth: `${design[type].borderWidth}px`,
                borderStyle: design[type].borderStyle,
                borderRadius: `${design[type].borderRadius}px`,
                margin: 0, // Margin handled by container in preview
                fontSize: `${design[type].fontSize}px`,
                boxShadow: design[type].shadow === 'none' ? 'none' : 'inset 0 2px 4px 0 rgb(0 0 0 / 0.05)'
            }}>
                <span>بیلګه متن</span>
            </div>
        </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto pb-20">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800">د مهال ویش ډیزاین</h2>
        <button 
            onClick={handleSave}
            className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-xl flex items-center gap-2 shadow-lg"
        >
            <Save size={20} />
            <span>بدلونونه ثبت کړئ</span>
        </button>
      </div>
      
      <div className="grid gap-6">
        {renderControls('lesson', 'د درس خونو سټایل')}
        {renderControls('break', 'د تفریح سټایل')}
      </div>
    </div>
  );
};

export default DesignPage;
