
import React, { useContext, useRef, useState } from 'react';
import { AppContext } from '../App';
import { Download, Upload, Printer, FileJson, AlertCircle, FileDown, Loader2, Eye } from 'lucide-react';
import ConfirmModal from './ConfirmModal';

interface Props {
  setPage: (page: string) => void;
}

const DataMgmt: React.FC<Props> = ({ setPage }) => {
  const { state, dispatch, addToast } = useContext(AppContext);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [pendingData, setPendingData] = useState<any>(null);

  // --- JSON Export ---
  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state));
    
    // Create a safe filename: timetable_backup_20231025.json
    const date = new Date();
    const dateStr = date.getFullYear() + 
                    String(date.getMonth() + 1).padStart(2, '0') + 
                    String(date.getDate()).padStart(2, '0');
    
    const filename = `timetable_backup_${dateStr}.json`;

    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", filename);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
    addToast('success', 'د شاتړ (Backup) فایل ډاونلوډ شو');
  };

  // --- JSON Import ---
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const json = JSON.parse(event.target?.result as string);
            // Check for minimal required fields
            // Even if some are missing, deepMerge in reducer will handle it, but we want to ensure it's roughly valid
            if (json && typeof json === 'object') {
                setPendingData(json);
                setIsImporting(true);
            } else {
                addToast('error', 'د فایل بڼه ناسمه ده');
            }
        } catch (err) {
            console.error(err);
            addToast('error', 'د فایل په لوستلو کې ستونزه');
        }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const confirmImport = () => {
    if (pendingData) {
        dispatch({ type: 'INIT', payload: pendingData });
        addToast('success', 'معلومات په بریالیتوب سره بار شول');
        setIsImporting(false);
        setPendingData(null);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">د معلوماتو او خروجي مدیریت</h2>
      
      <div className="grid gap-6">
        
        {/* JSON Section */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-3 mb-4">
                <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><FileJson /></div>
                <h3 className="font-bold text-lg">شاتړ (Backup) او بیا رغول (Restore)</h3>
            </div>
            <p className="text-slate-500 text-sm mb-6 leading-relaxed">
                ستاسو د پروګرام ټول معلومات لکه ښوونکي، ټولګي، ترتیبات او ډیزاین په شاتړ فایل کې ساتل کیږي.
                د فایل په پورته کولو سره کولی شئ خپل پروګرام پخواني حالت ته وګرځوئ.
            </p>
            <div className="flex gap-4 flex-col sm:flex-row">
                <button 
                    onClick={handleExportJSON}
                    className="flex-1 py-3 px-4 border-2 border-blue-100 hover:bg-blue-50 text-blue-700 rounded-xl flex items-center justify-center gap-2 transition-colors font-medium"
                >
                    <Download size={20} />
                    <span>د شاتړ فایل ډاونلوډ</span>
                </button>
                
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl flex items-center justify-center gap-2 transition-colors font-medium shadow-lg shadow-blue-200"
                >
                    <Upload size={20} />
                    <span>له فایل څخه بیا رغول</span>
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept=".json,application/json" 
                    onChange={handleFileChange} 
                />
            </div>
        </div>

        {/* Print / PDF Section */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-3 mb-4">
                <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600"><Printer /></div>
                <h3 className="font-bold text-lg">د چاپ او PDF مسلکي سټوډیو</h3>
            </div>
            <p className="text-slate-500 text-sm mb-6 leading-relaxed">
                سټوډیو ته ننوځئ ترڅو خپل PDF فایل د مسلکي تنظیماتو (واټر مارک، سرلیک، رنګونو) سره ډیزاین او ډاونلوډ کړئ.
            </p>
            
            <div className="flex gap-4 flex-col sm:flex-row">
                <button 
                    onClick={() => setPage('print-preview')}
                    className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl flex items-center justify-center gap-2 transition-colors font-medium shadow-lg shadow-indigo-200"
                >
                    <Eye size={20} />
                    <span>د PDF ډیزاین سټوډیو ته ننوتل</span>
                </button>
            </div>
        </div>

        {/* Info Box */}
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start gap-3 text-amber-800 text-sm">
            <AlertCircle className="flex-shrink-0 mt-0.5" size={18} />
            <p>
                یادونه: زاړه شاتړ فایلونه په اوتومات ډول د نوې نسخې سره سازګار کیږي، نو د معلوماتو د لاسه ورکولو په اړه اندیښنه مه کوئ.
            </p>
        </div>

      </div>

      <ConfirmModal 
        isOpen={isImporting}
        message="د فایل په بارولو سره به اوسني معلومات له منځه ولاړ شي او د نوي فایل معلومات به پر ځای شي. ایا ډاډه یاست؟"
        onCancel={() => { setIsImporting(false); setPendingData(null); }}
        onConfirm={confirmImport}
      />
    </div>
  );
};

export default DataMgmt;
