
import React, { useContext, useState } from 'react';
import { AppContext } from '../App';
import { Save } from 'lucide-react';

const SettingsPage: React.FC = () => {
  const { state, dispatch, addToast } = useContext(AppContext);
  const [values, setValues] = useState(state.settings);

  const handleChange = (key: keyof typeof values, value: any) => {
    setValues(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    dispatch({ type: 'RECORD' }); // Save history before changing structural settings
    dispatch({ type: 'UPDATE_SETTINGS', payload: values });
    addToast('success', 'د مهال ویش ترتیبات ثبت شول');
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">د مهال ویش ترتیبات</h2>
      
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 space-y-6">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">د ښوونځي د پیل وخت</label>
                <input 
                    type="time" 
                    value={values.startTime}
                    onChange={(e) => handleChange('startTime', e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
            </div>
            
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">د درسي ساعتونو شمېر</label>
                <input 
                    type="number" min="1" max="12"
                    value={values.totalLessons}
                    onChange={(e) => handleChange('totalLessons', parseInt(e.target.value))}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">د هر لوست موده (دقیقې)</label>
                <input 
                    type="number" min="15" max="120"
                    value={values.lessonDuration}
                    onChange={(e) => handleChange('lessonDuration', parseInt(e.target.value))}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">د تفریح/دمې موده (دقیقې)</label>
                <input 
                    type="number" min="5" max="60"
                    value={values.breakDuration}
                    onChange={(e) => handleChange('breakDuration', parseInt(e.target.value))}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
            </div>

            <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-2">له تفریح مخکې د ټولګیو شمېر</label>
                <input 
                    type="number" min="0" max="5"
                    value={values.lessonsBeforeBreak}
                    onChange={(e) => handleChange('lessonsBeforeBreak', parseInt(e.target.value))}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
                <p className="text-xs text-slate-500 mt-1">که ۰ وټاکئ، نو هیڅ تفریح به په پام کې ونه نیول شي.</p>
            </div>
        </div>

        <div className="pt-6 border-t border-slate-100 flex justify-end">
            <button 
                onClick={handleSave}
                className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-2 rounded-xl flex items-center gap-2 shadow-lg shadow-primary-900/20 transition-all"
            >
                <Save size={20} />
                <span>ثبتول</span>
            </button>
        </div>

      </div>
    </div>
  );
};

export default SettingsPage;
